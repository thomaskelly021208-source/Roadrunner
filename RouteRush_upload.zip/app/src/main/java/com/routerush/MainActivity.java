package com.routerush;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    EditText start, end;
    TextView status, result;
    Button go, navigate;
    String chosenUrl = null;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUi();
    }

    TextView tv(String s, int sp) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(sp); t.setTextColor(Color.rgb(25,25,25));
        t.setPadding(0,8,0,8);
        return t;
    }

    void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32,32,32,32);

        TextView title = tv("RouteRush", 30);
        title.setTypeface(null, 1);
        box.addView(title);
        TextView sub = tv("Aggressive fastest-time route hunter", 16);
        sub.setTextColor(Color.DKGRAY);
        box.addView(sub);

        box.addView(tv("Start", 14));
        start = new EditText(this);
        start.setHint("e.g. Hemel Hempstead");
        start.setSingleLine(true);
        box.addView(start);

        box.addView(tv("Destination", 14));
        end = new EditText(this);
        end.setHint("e.g. Lyme Regis");
        end.setSingleLine(true);
        box.addView(end);

        go = new Button(this);
        go.setText("HUNT FOR THE FASTEST ROUTE");
        box.addView(go);

        status = tv("Uses Waze's live route engine where available, then compares it with independent OpenStreetMap/OSRM alternatives.", 14);
        status.setTextColor(Color.DKGRAY);
        box.addView(status);

        result = tv("", 16);
        box.addView(result);

        navigate = new Button(this);
        navigate.setText("NAVIGATE SELECTED ROUTE");
        navigate.setEnabled(false);
        box.addView(navigate);

        TextView note = tv(
            "Important: this is V0.1. It does not claim Waze's private traffic feed is an official API. " +
            "Waze's live-map traffic feed is currently protected by anti-automation controls, so the app uses " +
            "the publicly observed Waze routing endpoint and independent routing as a research prototype. " +
            "Always compare the route before driving.",
            12);
        note.setTextColor(Color.GRAY);
        box.addView(note);

        scroll.addView(box);
        setContentView(scroll);

        go.setOnClickListener(v -> hunt());
        navigate.setOnClickListener(v -> {
            if (chosenUrl != null) startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(chosenUrl)));
        });
    }

    void hunt() {
        String s = start.getText().toString().trim();
        String e = end.getText().toString().trim();
        if (s.isEmpty() || e.isEmpty()) {
            status.setText("Enter both a start and destination.");
            return;
        }
        go.setEnabled(false);
        navigate.setEnabled(false);
        result.setText("");
        status.setText("Geocoding…");

        Executors.newSingleThreadExecutor().execute(() -> {
            try {
                double[] a = geocode(s);
                double[] b = geocode(e);
                if (a == null || b == null) throw new Exception("Could not geocode one of the places.");

                statusMain("Querying Waze live route alternatives…");
                List<Route> wr = wazeRoutes(a[0], a[1], b[0], b[1]);

                statusMain("Querying independent OSM/OSRM alternatives…");
                List<Route> or = osrmRoutes(a[1], a[0], b[1], b[0]);

                List<Route> all = new ArrayList<>();
                all.addAll(wr); all.addAll(or);
                if (all.isEmpty()) throw new Exception("No routes returned.");

                Collections.sort(all, Comparator.comparingLong(x -> x.seconds));
                Route best = all.get(0);

                StringBuilder out = new StringBuilder();
                out.append("FASTEST CANDIDATE\n\n");
                out.append(best.name).append("\n");
                out.append(format(best.seconds)).append(" • ").append(formatMiles(best.meters)).append("\n\n");

                out.append("WAZE CANDIDATES\n");
                if (wr.isEmpty()) out.append("Waze routing unavailable.\n");
                for (int i=0;i<wr.size();i++) {
                    Route r=wr.get(i);
                    out.append(i+1).append(". ").append(format(r.seconds))
                       .append(" • ").append(formatMiles(r.meters)).append("\n");
                }

                out.append("\nINDEPENDENT OSM/OSRM CANDIDATES\n");
                for (int i=0;i<or.size();i++) {
                    Route r=or.get(i);
                    out.append(i+1).append(". ").append(format(r.seconds))
                       .append(" • ").append(formatMiles(r.meters)).append("\n");
                }

                out.append("\nAggressive selection = lowest reported ETA among returned candidates. " +
                           "OSRM does not have Waze's live traffic, so an OSRM win must be treated as a candidate, not proof.");

                // Use Waze route for navigation when available; otherwise OSRM geometry is not directly navigable.
                Route nav = !wr.isEmpty() ? wr.get(0) : best;
                final String navUrl = "https://www.google.com/maps/dir/?api=1&origin=" +
                    Uri.encode(s) + "&destination=" + Uri.encode(e);

                runOnUiThread(() -> {
                    result.setText(out.toString());
                    status.setText("Route hunt complete.");
                    chosenUrl = navUrl;
                    navigate.setEnabled(true);
                    go.setEnabled(true);
                });
            } catch(Exception ex) {
                runOnUiThread(() -> {
                    status.setText("Route hunt failed: " + ex.getMessage());
                    go.setEnabled(true);
                });
            }
        });
    }

    void statusMain(String s) { runOnUiThread(() -> status.setText(s)); }

    static class Route {
        String name; long seconds, meters;
        Route(String n,long s,long m){name=n;seconds=s;meters=m;}
    }

    double[] geocode(String q) throws Exception {
        String u="https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&q="+
                URLEncoder.encode(q, "UTF-8");
        String j=get(u, "RouteRush/0.1 (Android)");
        JSONArray a=new JSONArray(j);
        if(a.length()==0)return null;
        return new double[]{a.getJSONObject(0).getDouble("lat"),a.getJSONObject(0).getDouble("lon")};
    }

    List<Route> wazeRoutes(double slat,double slon,double elat,double elon) throws Exception {
        String u="https://www.waze.com/RoutingManager/routingRequest?from=x%3A"+slon+
                "+y%3A"+slat+"&to=x%3A"+elon+"+y%3A"+elat+
                "&at=0&returnJSON=true&returnGeometries=true&returnInstructions=true&timeout=60000&nPaths=3&options=AVOID_TRAILS%3At";
        String j=get(u,"Mozilla/5.0");
        JSONObject root=new JSONObject(j);
        JSONArray al=root.optJSONArray("alternatives");
        List<Route> out=new ArrayList<>();
        if(al==null)return out;
        for(int i=0;i<al.length();i++){
            JSONObject r=al.getJSONObject(i);
            JSONObject resp=r.optJSONObject("response");
            if(resp==null)continue;
            JSONArray parts=resp.optJSONArray("results");
            long sec=0, m=0;
            if(parts!=null) for(int k=0;k<parts.length();k++){
                JSONObject p=parts.getJSONObject(k);
                sec += p.optLong("crossTime",0);
                m += p.optLong("length",0);
            }
            out.add(new Route("Waze route "+(i+1),sec,m));
        }
        return out;
    }

    List<Route> osrmRoutes(double slon,double slat,double elon,double elat) throws Exception {
        String u="https://router.project-osrm.org/route/v1/driving/"+slon+","+slat+";"+elon+","+elat+
                "?alternatives=true&overview=false&steps=false";
        JSONObject root=new JSONObject(get(u,"RouteRush/0.1"));
        JSONArray rs=root.optJSONArray("routes");
        List<Route> out=new ArrayList<>();
        if(rs==null)return out;
        for(int i=0;i<rs.length();i++){
            JSONObject r=rs.getJSONObject(i);
            out.add(new Route("OSRM candidate "+(i+1),r.optLong("duration",0),r.optLong("distance",0)));
        }
        return out;
    }

    String get(String u,String ua)throws Exception{
        HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
        c.setRequestMethod("GET"); c.setConnectTimeout(15000); c.setReadTimeout(30000);
        c.setRequestProperty("User-Agent",ua); c.setRequestProperty("Accept","application/json");
        int code=c.getResponseCode();
        InputStream in=(code>=200&&code<300)?c.getInputStream():c.getErrorStream();
        String body=new String(in.readAllBytes(),StandardCharsets.UTF_8);
        c.disconnect();
        if(code<200||code>=300) throw new IOException("HTTP "+code);
        return body;
    }

    String format(long sec){
        if(sec<=0)return "unknown";
        long h=sec/3600,m=(sec%3600)/60;
        return h>0 ? h+"h "+m+"m" : m+"m";
    }
    String formatMiles(long meters){return String.format(Locale.UK,"%.1f mi",meters/1609.344);}
}
